import os


def fn_example_script(event, context):
    print("Fiz uma modificacao")
